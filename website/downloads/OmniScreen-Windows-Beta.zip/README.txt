OmniScreen Reality Hub - Public Beta v0.9 (Windows)
===================================================

How to Run:
1. Extract this ZIP folder anywhere on your PC (for example, Desktop or Documents).
2. Double-click OmniScreen.exe.
   - Because this is an unsigned Public Beta build, Windows SmartScreen may show
     "Windows protected your PC". Click "More info" -> "Run anyway".
3. OmniScreen opens your dashboard and runs silently in your Windows System Tray
   (bottom-right taskbar). Closing the window keeps PC tracking active all day.
4. Right-click the OmniScreen tray icon anytime to:
   - Open OmniScreen Dashboard
   - Toggle "Start with Windows"
   - Quit OmniScreen cleanly

Privacy & Security:
- 100% local SQLite storage in %LOCALAPPDATA%\OmniScreen\omniscreen.db
- Zero cloud servers, zero accounts, zero external telemetry
- Administrative Hub controls are locked strictly to localhost (127.0.0.1)
